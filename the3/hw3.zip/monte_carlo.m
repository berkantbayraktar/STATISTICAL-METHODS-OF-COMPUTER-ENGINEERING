﻿%Size of Monte Carlo Simulation using Normal Approximation

epsilon = 0.005; 
probability = 0.95; 

N = (0.25) * ((norminv(probability + (1-probability)/2)) / epsilon)^2; 
% N is the number of Monte Carlo Simulation , this means that we will simulate this simulation N times.
%With probability 0.95, the answer will be different from the real value but no more than 0.005

%Simulation Part

poisson_lambda = 4;  %Poisson random variable with λ = 4

for i = 1:N  %Monte Carlo Simulation N times

	fish = poissrnd(poisson_lambda) + poissrnd(poisson_lambda) + poissrnd(poisson_lambda); % the number of caough fish
	total_weight = 0;

	for j = 1:fish
		total_weight = total_weight + fishing();  % fishing is a function that finds the weight of caught fish
	end;

	array_total(i) = total_weight;
end;

function X = fishing()
	%The function "fish" finds the weight of fish that caught 
	%Using rejection method
	%I chose bouinding box with a = 0 , b = 3 , c = 0.7

    a = 0 ;  b = 3 ; c = 0.7 ;
    
	while true
		
        U = rand; V = rand; 
        X = a+(b-a)*U; Y = c*V;  
        x = rand*3;
    
		if  (x >= 0) & (x <= 1)
			if Y <= ((0.4 * X^3) - (0.6 * X^2) + 0.3)
			    break; % break the function because we find the weight of fish
            end;

		elseif (x > 1) & (x <= 2)
			if Y <= ((-1.2 * (X-1)^3) + (1.8 * (X-1)^2) + 0.1)
        		break;% break the function because we find the weight of fish
            end;
            
   		elseif (x > 2) & (x <= 3)
    		if Y <= ((1.2 * (X-2)^3) - (1.8 * (X-2)^2) + 0.7)
    	        break;	% break the function because we find the weight of fish
	    	end;
		end;
	end;
	
endfunction

[mean(array_total>25),mean(array_total),std(array_total)]
%[part a) probability , part b) total_weight,part c) std]